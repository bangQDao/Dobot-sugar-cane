function qn = parseQ(q)
    qn = q;
    qn(3) = q(3)-pi/2+q(2);
end